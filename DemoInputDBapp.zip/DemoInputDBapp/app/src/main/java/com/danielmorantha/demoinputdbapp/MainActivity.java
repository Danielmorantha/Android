package com.danielmorantha.demoinputdbapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements LocationListener {

    EditText edtIDVar, edtNamaMhsVar, edtNimVar;
    private TextView Latitude, Longitude, Altitude;
    private Button button;
    private FusedLocationProviderClient locationProviderClient;
//
//    EditText edtNmaMhs, edtNimMhs;
    TextView txtAlamat;
    LocationManager locationManager;

    DatabaseManager dbManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Latitude = findViewById(R.id.LblLatitude);
        Longitude = findViewById(R.id.LblLongitude);
        Altitude = findViewById(R.id.LblAtitude);
        txtAlamat = findViewById(R.id.txtAlamat);

        edtIDVar = (EditText) findViewById(R.id.edtID);
        edtNamaMhsVar = (EditText) findViewById(R.id.edtNamaMhs);
        edtNimVar = (EditText) findViewById(R.id.edtNim);

        button = findViewById(R.id.button);

        dbManager = new DatabaseManager(this);
        try {
            dbManager.open();
        }catch (Exception e)
        {
            e.printStackTrace();
        }


        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED)
        {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, 100);
        }

        locationProviderClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);

        button.setOnClickListener(v -> {
            getLocation();
        });
    }

    public void btnTambahPressed(View v)
    {
        dbManager.insert(edtNamaMhsVar.getText().toString(), edtNimVar.getText().toString());
    }

    public void btnLihatPressed(View v)
    {
        Cursor cursor = dbManager.fetch();

        if (cursor.moveToFirst())
        {
            do {
                String ID = cursor.getString(cursor.getColumnIndex(DatabaseHelper.USER_ID));
                String username = cursor.getString(cursor.getColumnIndex(DatabaseHelper.USER_NAME));
                String nim = cursor.getString(cursor.getColumnIndex(DatabaseHelper.USER_NIM));
                Log.i("DATABASE_TAG", "Datanya disini : " + ID + " NAMA: " + username + " NIM : " +nim);
            }while (cursor.moveToNext());
        }
    }

    public  void btnUbahPressed(View v)
    {
        dbManager.update(Long.parseLong(edtIDVar.getText().toString()) , edtNamaMhsVar.getText().toString(), edtNimVar.getText().toString());
    }

    public void btnHapusPressed(View v)
    {
        dbManager.delete(Long.parseLong(edtIDVar.getText().toString()));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10)
        {
            if (ActivityCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getApplicationContext(), "Izin Lokasi Tidak di aktifkan", Toast.LENGTH_SHORT).show();
            }else
            {
                getLocation();
            }
        }
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            //Mengambil Lokasi
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, 10 );
        }else
        {
            locationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @SuppressLint("MissingPermission")
                @Override
                public void onSuccess(Location location) {
                    if (location!=null) {
                        Latitude.setText(String.valueOf(location.getLatitude()));
                        Longitude.setText(String.valueOf(location.getLongitude()));
                        Altitude.setText(String.valueOf(location.getAltitude()));
                        locationManager = (LocationManager) getApplicationContext().getSystemService(LOCATION_SERVICE);
                        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 5000,5,MainActivity.this);
                    }else{
                        Toast.makeText(getApplicationContext(), "Lokasi tidak aktif!", Toast.LENGTH_SHORT).show();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getApplicationContext(), e.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
                }
            });

        }


    }



    @Override
    public void onLocationChanged(@NonNull Location location) {

        Toast.makeText(this, ""+location.getLatitude()+""+location.getLongitude(), Toast.LENGTH_SHORT).show();

        try {
            Geocoder geocoder = new Geocoder(MainActivity.this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(),location.getLongitude(),1);
            String address = addresses.get(0).getAddressLine(0);

            txtAlamat.setText(address);
        }catch (Exception e)
        {
            e.printStackTrace();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        LocationListener.super.onStatusChanged(provider, status, extras);
    }

    @Override
    public void onProviderEnabled(@NonNull String provider) {
        LocationListener.super.onProviderEnabled(provider);
    }

    @Override
    public void onProviderDisabled(@NonNull String provider) {
        LocationListener.super.onProviderDisabled(provider);
    }
}